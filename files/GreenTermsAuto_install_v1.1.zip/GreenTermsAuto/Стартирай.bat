@echo off
cd /d "%~dp0"
if not exist "GreenTermsAuto.html" goto missing
set "PS=%TEMP%\gta_launch.ps1"
> "%PS%" echo param([string]$AppDir)
>>"%PS%" echo Set-Location $AppDir
>>"%PS%" echo $html = Join-Path $AppDir 'GreenTermsAuto.html'
>>"%PS%" echo if (-not (Test-Path $html)) { exit 1 }
>>"%PS%" echo $u = ([uri]$html).AbsoluteUri
>>"%PS%" echo $cands = @(
>>"%PS%" echo (${env:ProgramFiles(x86)} + '\Microsoft\Edge\Application\msedge.exe'),
>>"%PS%" echo ($env:ProgramFiles + '\Microsoft\Edge\Application\msedge.exe'),
>>"%PS%" echo ($env:ProgramFiles + '\Google\Chrome\Application\chrome.exe'),
>>"%PS%" echo (${env:ProgramFiles(x86)} + '\Google\Chrome\Application\chrome.exe'),
>>"%PS%" echo ($env:LocalAppData + '\Google\Chrome\Application\chrome.exe'),
>>"%PS%" echo ($env:ProgramFiles + '\BraveSoftware\Brave-Browser\Application\brave.exe'),
>>"%PS%" echo ($env:LocalAppData + '\Vivaldi\Application\vivaldi.exe'),
>>"%PS%" echo ($env:LocalAppData + '\Programs\Opera\opera.exe'))
>>"%PS%" echo $b = $null
>>"%PS%" echo foreach ($c in $cands) { if (Test-Path $c) { $b = $c; break } }
>>"%PS%" echo if (-not $b) { Start-Process $html; exit }
>>"%PS%" echo $prof = Join-Path $env:LocalAppData 'GreenTermsAuto\Profile'
>>"%PS%" echo $proc = Start-Process $b -ArgumentList ('--user-data-dir="'+$prof+'"'),('--app="'+$u+'"'),'--start-maximized','--no-first-run' -PassThru
>>"%PS%" echo Add-Type -Namespace U -Name W -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(System.IntPtr h, int c);'
>>"%PS%" echo for ($i = 0; $i -lt 20; $i++) {
>>"%PS%" echo Start-Sleep -Milliseconds 300
>>"%PS%" echo $proc.Refresh()
>>"%PS%" echo if ($proc.HasExited) { break }
>>"%PS%" echo if ($proc.MainWindowHandle -ne 0) { [U.W]::ShowWindowAsync($proc.MainWindowHandle, 3); break }
>>"%PS%" echo }
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS%" -AppDir "%CD%"
if errorlevel 1 goto missing
exit /b

:missing
echo.
echo  ERROR: GreenTermsAuto.html not found in: %CD%
echo  Kopirajte CQLATA papka na kompjutara,
echo  posle pusnete Startiraj.bat ot neja.
echo.
pause
